//This code is for Conditional's Lab work to test if/else statements:

var studentPoint = 55
if (studentPoint >= 90) {
    console.log("A")
} else if (studentPoint >= 80 && studentPoint < 90) {
    console.log("B")
} else if (studentPoint >= 70 && studentPoint < 80) {
    console.log("C")
} else if (studentPoint >= 55 && studentPoint < 70) {
    console.log("D")
} else {
    console.log("F")
}
